* Constants for Stonefield base classes.

#include FOXPRO.H
#include SFERRORS.H
#include SFCTRLCHAR.H
