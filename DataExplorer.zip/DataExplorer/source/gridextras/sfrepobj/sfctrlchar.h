* Control character constants.

#define ccCRLF                  chr(13) + chr(10)
#define ccCR                    chr(13)
#define ccNULL                  chr(0)
#define ccTAB                   chr(9)
